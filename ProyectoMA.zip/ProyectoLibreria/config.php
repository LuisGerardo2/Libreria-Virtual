<?php
$db = [
    'host' => 'localhost',
    'username' => 'root',
    'password' => '',
    'db' => 'libros' //Cambiar al nombre de tu base de datos
];
?>