<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="..\css\style.css">
    <link rel="stylesheet" href="..\css\login.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <title>Document</title>
</head>
<body>

    <!-- Header -->
   <?php 
    include('header.html');
   ?>

    <div class="">
      <div class="">
          <h2>Agrega un libro</h2>
          <center>
 <section>
          <!-- Formulario -->
          <form action="../phpLibros/registerBook_process.php" method="POST" enctype="multipart/form-data">
              <label for="titulo">Título del Libro</label>
              <input type="text" id="titulo" name="titulo" required><br><br>

              <label for="autores">Autores</label>
              <input type="text" id="autores" name="autores" placeholder="Autor1, Autor2" required><br><br>

              <label for="apublicacion">Año de Publicación</label>
              <input type="number" id="apublicacion" name="apublicacion" required><br><br>

              <label for="generos">Géneros</label>
              <input type="text" id="generos" name="generos" placeholder="Romance, drama, aventura,..." required><br><br>

              <label for="sinopsis">Sinopsis</label>
              <textarea id="sinopsis" name="sinopsis" required></textarea><br><br>

              <label for="reseñas">Reseñas</label>
              <textarea id="resenas" name="resenas" required></textarea><br><br>

              <label for="portada">Sube una portada del libro</label>
              <input type="file" id="portada" name="portada" required><br><br>

              <label for="virtual">Virtual</label>
              <input type="checkbox" id="virtual" name="virtual" value="Virtual" onchange="verificar();"><br><br>


                  <div style="display: none;" id="libroV">
             
             
              <label for="contenido">Contenido del Libro</label>
              <input type="file" id="contenido" name="contenido"><br><br>

             </div>

              <button type="submit" class="submit-button">Crear Libro</button>
          </form>
      </div>
  </div>
</section>  
</center>   
     <!-- Footer -->
     <footer class="footer">
        <p>2024 VersaBooks. All rights reserved.</p>
      </footer>
    
</body>
<script type="text/javascript">
  function verificar() {
      var virtual=document.getElementById('virtual');
      var lv=document.getElementById('libroV');
             if (virtual.checked){
           
           lv.style.display="block";}else{lv.style.display="none";

           }
  }
</script>
</html>